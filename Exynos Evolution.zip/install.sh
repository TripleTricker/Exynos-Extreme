SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
MODDIR="/data/adb/modules"

# Installation UI
ui_print " "
ui_print "********************************************"
ui_print "* SPECIAL THANKS FOR ALL MODULE DEVELOPERS *"
ui_print "********************************************"
ui_print " "

sleep 2
echo " ☆ Welcome to The Realm of Performance ☆ "
echo ""
sleep 2
echo " 𝗗𝗲𝘃𝗶𝗰𝗲 𝗜𝗻𝗳𝗼 "
sleep 0.2
echo " ● BRAND    : $(getprop ro.product.brand)  "
sleep 0.2
echo " ● MODEL    : $(getprop ro.product.model)  "
sleep 0.2
echo " ● DEVICE   : $(getprop ro.product.name)  "
sleep 0.2
echo " ● KERNEL   : $(uname -r)  "
sleep 0.2
echo " ● BOARD    : $(getprop ro.board.platform) "
sleep 0.2
echo " ● CPU INFO : $(getprop ro.hardware.chipname)  "
sleep 0.2
echo " ● GPU INFO : $(getprop ro.hardware.egl)  "
sleep 0.2
echo " ● ARC INFO : $(getprop ro.product.cpu.abi)  "
sleep 0.2
echo " ● MEMORY   : $(grep MemTotal /proc/meminfo | awk '{print $2,$3}' ) "
sleep 0.2
echo " ● SELINUX  : $(getprop ro.boot.selinux)  "
sleep 0.2
echo " ● Don't need to be supported  "
sleep 0.2
echo " ● Build & Develop for Exynos Variants  "
sleep 0.2
echo " ● This module is a collection of Essentials "
sleep 2
echo ""
echo " ☆ Applying tweaks depend on specifics ☆ "
echo ""
sleep 2

# Extracting files
echo "- Extracting module files"
on_install() {
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'custom/*' -d $MODPATH >&2
}
sleep 0.2
echo "- Extracting all files complete"
sleep 0.2

# Removing old files
if [ -e /data/adb/modules/$(ls /data/adb/modules | grep Exy) ]; then
echo "- Exynos $(grep name /data/adb/modules/$(ls /data/adb/modules | grep Exy)/module.prop | awk '{print $2}' ) Detected"
sleep 0.2
echo "- Removing old files ...   "
rm -rf /data/adb/modules/$(ls /data/adb/modules | grep Exy)
fi
sleep 0.2
# Setting permission
set_permissions() {
set_perm_recursive $MODPATH 0 0 0777 0755
}
sleep 0.2
# Complete install
cleanup