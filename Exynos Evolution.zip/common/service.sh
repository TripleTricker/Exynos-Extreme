#!/system/bin/sh
MODDIR=${0%/*}

# Wait until system boot
until [ "$(getprop sys.boot_completed)" == "1" ]
do
sleep 15
done

##### SETTINGS WRITE PERMISSION #####
# Thanks tytydraco for permission to write file
write() {
	[[ ! -f "$1" ]] && return 1
	chmod +w "$1" 2> /dev/null
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
	echo "$1 → $2"
}

# Force start vsync
set start vsync

##### DISABLE THERMAL THROTTLE #####
# Overwrite thermal properties
for thermal in $(resetprop -n | awk -F '[][]' '/thermal/ {print $2}'); do
if [ "$(resetprop -n "$thermal")" = "running" ]; then
resetprop -n  "$thermal" "stopped"; fi
done

# Anti-block CPU freq
for cpu in /sys/devices/system/cpu/cpufreq/*; do
chmod 444 "$cpu/scaling_max_freq"
write "$cpu/schedutil/freqvar_boost" 0
write "$cpu/schedutil/freqvar_down_rate_limit" 0
write "$cpu/schedutil/freqvar_st_boost" 0
write "$cpu/schedutil/freqvar_up_rate_limit" 0
done

# Thermal cpu control
zone="/sys/class/thermal"
if [ -d "$zone" ]; then
for tem in $zone/thermal_zone* ; do
write "$tem/policy" step_wise
write "$tem/trip_point_0_temp" 150000
done
fi

#####  PERFORMANCE TWEAK #####
# GPU config tweak
egl="/sys/devices/platform/$(ls /sys/devices/platform | grep mali)"
if [ -d "$egl" ]; then
chmod 000 "$egl/dvfs"
chgrp root "$egl/dvfs_max_lock"
chown root "$egl/dvfs_max_lock"
chmod 000 "$egl/dvfs_max_lock"
chgrp root "$egl/dvfs_min_lock"
chown root "$egl/dvfs_min_lock"
chmod 000 "$egl/dvfs_min_lock"
chmod 000 "$egl/dvfs_max_lock_status"
chmod 000 "$egl/dvfs_min_lock_status"
write "$egl/dvfs_governor" 5
write "$egl/highspeed_clock" "$(cat /sys/kernel/gpu/gpu_max_clock)"
write "$egl/power_policy" always_on
fi

# GPU maxfreq lock
gpumax="/sys/kernel/gpu/gpu_max_clock"
if [ -f "$gpumax" ]; then
write "$gpumax" "$(cat /sys/kernel/gpu/gpu_freq_table | awk '{print $7}')"
fi

# CPU top-app optimize
for top in /dev/*/top-app; do
write "$top/memory_migrate" 1
write "$top/memory_spread_page" 1
write "$top/schedtune.boost" 60
write "$top/schedtune.prefer_idle" 0
write "$top/schedtune.prefer_perf" 0
done

# Apply I/O Tweak
for queue in /sys/block/*/queue; do
write "$queue/iostats" 0
write "$queue/rq_affinity" 2
write "$queue/nomerges" 2
write "$queue/nr_requests" 512
write "$queue/read_ahead_kb" 256
done

# Other memory tweak
mem="/dev/memcg"
if [ -d "$mem" ]; then
write "$mem/memory.use_hierarchy" 1
write "$mem/apps/memory.move_charge_at_immigrate" 1
fi

# ZRAM optimize 
for zr0 in /sys/block/zram0; do
write "$zr0/disksize" 0
write "$zr0/max_comp_streams" 8
write "$zr0/reset" 1
done

for zrm in /dev/block; do
swapoff "$zrm/zram0" > /dev/null 2>&1
mkswap "$zrm/zram0" > /dev/null 2>&1
done

##### KTWEAK THROUGHPUT  #####
# Group of kernel tweak
perf="/proc/sys/kernel"
if [ -d "$perf" ]; then
write "$perf/perf_cpu_time_max_percent" 25
write "$perf/perf_event_max_contexts_per_stack" 128
write "$perf/perf_event_mlock_kb" 4000
write "$perf/perf_event_paranoid" -1
write "$perf/perf_event_max_sample_rate" 400000
write "$perf/printk_devkmsg" off
write "$perf/sched_child_runs_first" 1
write "$perf/timer_migration" 0
write "$perf/keys/gc_delay" 100
write "$perf/keys/maxbytes" 20000
write "$perf/keys/maxkeys" 200
write "$perf/pty/max" 6144
fi

# Virtual Memory tweak
virtual="/proc/sys/vm"
if [ -d "$virtual" ]; then
write "$virtual/block_dump" 1
write "$virtual/compact_memory" 0
write "$virtual/dirty_background_ratio" 100
write "$virtual/dirty_ratio" 100
write "$virtual/dirty_expire_centisecs" 6000
write "$virtual/dirty_writeback_centisecs" 6000
write "$virtual/drop_caches" 6
write "$virtual/extra_free_kbytes" 10240
write "$virtual/oom_dump_tasks" 0
write "$virtual/oom_kill_allocating_task" 0
write "$virtual/overcommit_ratio" 80
write "$virtual/page-cluster" 0
write "$virtual/panic_on_oom" 0
write "$virtual/stat_interval" 120
write "$virtual/swappiness" 200
write "$virtual/vfs_cache_pressure" 200
fi

# Net tcp tweak
tcp="/proc/sys/net/ipv4"
if [ -d "$tcp" ]; then
write "$tcp/tcp_ecn" 1
write "$tcp/tcp_fastopen" 3
write "$tcp/tcp_low_latency" 1
write "$tcp/tcp_sack" 1
write "$tcp/tcp_syncookies" 0
write "$tcp/tcp_timestamps" 0
fi

# Parameters tweak
for paradir in /sys/module/*/parameters; do
write "$paradir/debug_mask" 0
write "$paradir/fnmode" 0
write "$paradir/ignore_loglevel" Y
write "$paradir/ignore_special_drivers" 0
write "$paradir/log_ecn_error" N
write "$paradir/off" 1
write "$paradir/power_efficient" Y
write "$paradir/scroll_acceleration" Y
write "$paradir/scroll_speed" 0
write "$paradir/time" N
write "$paradir/use_spi_crc" 0
done

##### OTHER SYSTEM TWEAK #####
# CPU tweak
if [ -d "/sys/kernel" ]; then
for rcu in /sys/kernel; do
write "$rcu/rcu_normal" 0
write "$rcu/rcu_expedited" 1
done
fi

# Battery tweak
if [ -d "/sys/power" ]; then
for bat in /sys/power; do
write "$bat/autosleep" mem
write "$bat/mem_sleep" deep
write "$bat/pm_freeze_timeout" 60000
done
fi

# Off tombstoned
for SERVICE in tombstoned; do
stop $SERVICE
done

# Optimization TCP
ip route | while read p; do 
ip route change $p initcwnd 20 initrwnd 20
done

# KERNEL PANIC OFF
sysctl -w fs.inotify.max_user_watches=2147483647
sysctl -w kernel.panic=0
sysctl -w kernel.panic_on_oops=0
sysctl -w kernel.softlockup_panic=0
sysctl -w net.ipv4.tcp_congestion_control=wvegas
sysctl -w vm.panic_on_oom=0

# Performance Proptweak
resetprop -n dalvik.vm.dexopt-flags m=y
resetprop -n dalvik.vm.execution-mode int:jit
resetprop -n dalvik.vm.jmiopts forcecopy
resetprop -n debug.app.performance_restricted 0
resetprop -n debug.choreographer.callback 120
resetprop -n debug.choreographer.skipwarning 16
resetprop -n debug.composition.sync_mode 1
resetprop -n debug.composition.type auto
resetprop -n debug.cpurend.vsync 0
resetprop -n debug.disable_sched_boost 1
resetprop -n debug.egl.buffcount 4
resetprop -n debug.egl.force_msaa 1
resetprop -n debug.egl.hw 0
resetprop -n debug.egl.sync 0
resetprop -n debug.egl.swapinterval 0
resetprop -n debug.enabletr 1
resetprop -n debug.gfx.driver 1
resetprop -n debug.gralloc.gfx_ubwc_disable 0
resetprop -n debug.gralloc.enable_fb_ubwc 1
resetprop -n debug.gr.numframebuffers 5
resetprop -n debug.gr.swapinterval 0
resetprop -n debug.hwc.bq_count 3
resetprop -n debug.hwc.compose_level 0
resetprop -n debug.hwui.disabledither 1
resetprop -n debug.hwui.disable_draw_defer 1
resetprop -n debug.hwui.disable_draw_reorder 1
resetprop -n debug.hwui.enable_partial_updates 0
resetprop -n debug.hwui.render_dirty_regions 0
resetprop -n debug.hwui.render_priority 1
resetprop -n debug.hwui.renderer skiagl
resetprop -n debug.hwui.skia_atrace_enabled 0
resetprop -n debug.hwui.skip_empty_damage 1
resetprop -n debug.hwui.use_buffer_age 0
resetprop -n debug.hwui.use_threaded_rendering 1
resetprop -n debug.mali.disable_backend_affinity 0
resetprop -n debug.MB.inner.running 37
resetprop -n debug.MB.running 23
resetprop -n debug.multicore.processing 1
resetprop -n debug.overlayui.enable 1
resetprop -n debug.OVRManager.cpuLevel 3
resetprop -n debug.OVRManager.gpuLevel 3
resetprop -n debug.OVRPlugin.systemDisplayFrequency 120
resetprop -n debug.performance.tuning 1
resetprop -n debug.performance_schema 1
resetprop -n debug.performance_schema_max_memory_classes 387
resetprop -n debug.performance_schema_max_socket_classes 10
resetprop -n debug.renderengine.backend skiaglthreaded
resetprop -n debug.renderengine.skia_tracing_enabled 0
resetprop -n debug.rs.default-CPU-driver 1
resetprop -n debug.rs.default-GPU-driver 1
resetprop -n debug.renderthread.reduceopstasksplitting 1
resetprop -n debug.rs.precision rs_fp_full
resetprop -n debug.skia.layers EGL_KHR_gl_texture_cubemap_image,EGL_KHR_gl_texture_3D_image,EGL_KHR_gl_renderbuffer_image
resetprop -n debug.sf.disable_client_composition_cache 1
resetprop -n debug.sf.early_app_phase_offset_ns 500000
resetprop -n debug.sf.early_gl_app_phase_offset_ns 15000000
resetprop -n debug.sf.early_gl_phase_offset_ns 3000000
resetprop -n debug.sf.early_phase_offset_ns 500000
resetprop -n debug.sf.enable_gl_backpressure 0
resetprop -n debug.sf.enable_hgl 1
resetprop -n debug.sf.enable_hwc_vds 1
resetprop -n debug.sf.enable_layer_caching 1
resetprop -n debug.sf.hw 0
resetprop -n debug.sf.high_fps_early_gl_phase_offset_ns 650000
resetprop -n debug.sf.high_fps_early_phase_offset_ns 6100000
resetprop -n debug.sf.high_fps_late_app_phase_offset_ns 100000
resetprop -n debug.sf.latch_unsignaled 1
resetprop -n debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
resetprop -n debug.sf.predict_hwc_composition_strategy 1
resetprop -n debug.sf.use_phase_offsets_as_durations 1
resetprop -n debug.systemuicompilerfilter speed
resetprop -n device.internal 1
resetprop -n hw2d.force 1
resetprop -n hwui.disable_vsync 0
resetprop -n hwui.render_dirty_regions 0
resetprop -n net.ipv4.tcp_timestamps 1
resetprop -n net.ipv4.tcp_window_scaling 1
resetprop -n net.tethering.noprovisioning 1
resetprop -n persist.android.strictmode 0
resetprop -n persist.cust.tel.eons 1
resetprop -n persist.dev.pm.dyn_samplingrate 1
resetprop -n persist.device_config.runtime_native.usap_pool_enabled 0
resetprop -n persist.hwc.mdpcomp.enable 1
resetprop -n persist.radio.add_power_save 1
resetprop -n persist.radio.apm_sim_not_pwdn 1
resetprop -n persist.radio.no_wait_for_card 1
resetprop -n persist.ro.config.hw_quickpoweron 1
resetprop -n persist.sampling_profiler 0
resetprop -n persist.service.lgospd.enable 0
resetprop -n persist.service.pcsync.enable 0 
resetprop -n persist.sys.composition.type auto
resetprop -n persist.sys.cpu.renderthreads 1
resetprop -n persist.sys.fflag.override.settings_enable_monitor_phantom_procs 0
resetprop -n persist.sys.purgeable_assets 1
resetprop -n persist.sys.shutdown.mode hibernate
resetprop -n persist.sys.spc.cpulimit.enabled 0
resetprop -n persist.sys.sqlite.force.compact 1
resetprop -n persist.sys.scrollingcache 3
resetprop -n persist.sys.sf.native_mode 1
resetprop -n persist.sys.ui.hw 1
resetprop -n persist.sys.use_16bpp_alpha 1
resetprop -n persist.sys.use_dithering 0
resetprop -n persist.vendor.power.dfps.level 0
resetprop -n persist.vendor.qti.inputopts.enable 1
resetprop -n persist.vendor.qti.inputopts.movetouchslop 0.6
resetprop -n persist.vendor.vcb.ability 1
resetprop -n persist.vendor.vcb.enable 1
resetprop -n persist.volte_enabled_by_hw 1
resetprop -n pm.sleep_mode 1
resetprop -n power.saving.mode 1
resetprop -n power_supply.wakeup enable
resetprop -n ro.config.combined_signal 1
resetprop -n ro.config.dha_tunnable 1
resetprop -n ro.config.enable.hw_accel 1
resetprop -n ro.config.hw_fast_dormancy 1
resetprop -n ro.config.hw_power_saving 1
resetprop -n ro.config.hw_quickpoweron 1
resetprop -n ro.fb.mode 1
resetprop -n ro.gfx.angle.supported 0
resetprop -n ro.HOME_APP_ADJ 1
resetprop -n ro.hw.use_disable_composition_type_gles 0
resetprop -n ro.hw.use_enable_composition_type_gles 1
resetprop -n ro.hwui.font_smoothing 1
resetprop -n ro.hwui.max_frame_time 16.8
resetprop -n ro.hwui.renderer.backend_frame-fps 60-120
resetprop -n ro.hwui.use_skiagl 1
resetprop -n ro.hwui.use_vulkan 0
resetprop -n ro.ksm.default 1
resetprop -n ro.media.dec.jpeg.memcap 8000000
resetprop -n ro.media.enc.hprof.vid.bps 8000000
resetprop -n ro.media.enc.hprof.vid.fps 120
resetprop -n ro.media.enc.jpeg.quality 100
resetprop -n ro.minui.pixel_format RGBX_8888
resetprop -n ro.product.gpu.driver 1
resetprop -n ro.ril.disable.power.collapse 1
resetprop -n ro.ril.enable.amr.wideband 1
resetprop -n ro.ril.sensor.sleep.control 1
resetprop -n ro.secure 0
resetprop -n ro.sf.compbypass.enable 0
resetprop -n ro.sf.disable_app_use_render_thread 0
resetprop -n ro.sf.lcd_density 560
resetprop -n ro.surface_flinger.max_frame_buffer_acquired_buffers 4
resetprop -n ro.surface_flinger.max_texture_buffer_acquired_buffers 4
resetprop -n ro.surface_flinger.max_frame_latency 18.6
resetprop -n ro.surface_flinger.running_without_sync_framework 0
resetprop -n ro.surface_flinger.set_touch_timer_ms 100
resetprop -n ro.surface_flinger.supports_background_blur 0
resetprop -n ro.surface_flinger.use_content_detection_for_refresh_rate 0
resetprop -n ro.surface_flinger.use_frame_rate_api 1
resetprop -n ro.vendor.dfps.enable 0
resetprop -n ro.vendor.perf.scroll_opt 1
resetprop -n ro.vendor.qti.config.zram 0
resetprop -n ro.vendor.qti.core.ctl_max_cpu 4
resetprop -n ro.vendor.qti.core.ctl_min_cpu 2
resetprop -n ro.vendor.qti.sys.fw.bg_apps_limit 600
resetprop -n ro.vendor.qti.sys.fw.bservice_enable 1
resetprop -n ro.vendor.qti.sys.fw.bservice_limit 60
resetprop -n ro.vendor.smart_dfps.enable 0
resetprop -n ro.vold.umsdirtyratio 20
resetprop -n ro.zygote.disable_gl_preload 1
resetprop -n renderthread.skia.reduceopstasksplitting 1
resetprop -n sys.egl.enable_preload 0
resetprop -n tombstoned.max_anr_count 0
resetprop -n tombstoned.max_tombstone_count 0
resetprop -n vendor.display.disable_skip_validate 1
resetprop -n vendor.display.enable_optimize_refresh 1
resetprop -n vendor.display.use_layer_ext 0
resetprop -n vendor.display.use_smooth_motion 1
resetprop -n vendor.gralloc.disable_ubwc 0
resetprop -n vendor.performance.tunning 1
resetprop -n vendor.powerhal.audio AUDIO_STREAMING_LOW_LATENCY
resetprop -n vendor.powerhal.dalvik.vm.dex2oat-cpu-set 0,1,2,3,4,5,7
resetprop -n vendor.powerhal.dalvik.vm.dex2oat-threads 6
resetprop -n vendor.powerhal.rendering EXPENSIVE_RENDERING
resetprop -n vendor.powerhal.state SUSTAINED_PERFORMANCE
resetprop -n vendor.user_experience 1
resetprop -n vendor.video.disable.ubwc 1
resetprop -n video.accelerate.hw 1
resetprop -n vidc.debug.level 0
resetprop -n wifi.supplicant_scan_interval 300
resetprop -n windowsmgr.max_events_per_sec 120

# System settings tweak
cmd power set-fixed-performance-mode-enabled true
cmd power set-adaptive-power-saver-enabled true
cmd thermalservice override-status 0
cmd activity kill-all
device_config put activity_manager max_phantom_processes 2147483647

#####  The End Of Module  #####
exit 0